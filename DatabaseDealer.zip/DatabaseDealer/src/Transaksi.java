import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Transaksi {
    private int No_transaksi;
    private String Tgl_transaksi;
    private String Metode_pembayaran;
    private String Status_pembayaran;
    private String Total_pembayaran;

    public Transaksi(int No_transaksi, String Tgl_transaksi, String Metode_pembayaran, String Status_pembayaran, String Total_pembayaran) {
        this.No_transaksi = No_transaksi;
        this.Tgl_transaksi = Tgl_transaksi;
        this.Metode_pembayaran = Metode_pembayaran;
        this.Status_pembayaran= Status_pembayaran;
        this.Total_pembayaran = Total_pembayaran;
    }

    // Getter and Setter methods for the fields (id, nama, alamat, telepon)

    public static Transaksi getTransaksi(int No_transaksi) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Menghubungkan ke database
            String url = "jdbc:mysql://localhost:3306/dealer_mobil";
            String user = "root";
            String password = "";
            connection = DriverManager.getConnection(url, user, password);

            // Query untuk mendapatkan pembeli berdasarkan ID
            String query = "SELECT * FROM transaksi WHERE No_transaksi = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, No_transaksi);

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int No_Transaksi = resultSet.getInt("No_transaksi");
                String Tgl_transaksi = resultSet.getString("Tgl_transaksi");
                String Metode_pembayaran = resultSet.getString("Metode_pembayarani");
                String Status_pembayaran = resultSet.getString("Status_pembayaran");
                String Total_pembayaran = resultSet.getString("Total_pembayaran");

                return new Transaksi(No_Transaksi,Tgl_transaksi,Metode_pembayaran,  Status_pembayaran, Total_pembayaran);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Tutup koneksi database
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return null;
    }
}
