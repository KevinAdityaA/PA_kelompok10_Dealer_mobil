/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataBase1;

/**
 *
 * @author ASUS
 */
public class Kendaraan1 {
    int roda;
    String bahanBakar;
    String vin;
    String merekMobil;
    double hargaMobil;
    String warnaMobil;
    String pabrikasi;
    int tahunPabrikasi;

    Kendaraan1(int roda, String bahanBakar, String vin, String merekMobil, double hargaMobil, String warnaMobil, String pabrikasi, int tahunPabrikasi) {
        this.roda = roda;
        this.bahanBakar = bahanBakar;
        this.vin = vin;
        this.merekMobil = merekMobil;
        this.hargaMobil = hargaMobil;
        this.warnaMobil = warnaMobil;
        this.pabrikasi = pabrikasi;
        this.tahunPabrikasi = tahunPabrikasi;
    }

    void info() {
        System.out.println("Kendaraan dengan " + roda + " roda, menggunakan " + bahanBakar + " sebagai bahan bakar");
        System.out.println("VIN: " + vin);
        System.out.println("Merek Mobil: " + merekMobil);
        System.out.println("Harga Mobil: " + hargaMobil);
        System.out.println("Warna Mobil: " + warnaMobil);
        System.out.println("Pabrikasi: " + pabrikasi);
        System.out.println("Tahun Pabrikasi: " + tahunPabrikasi);
    }
}
