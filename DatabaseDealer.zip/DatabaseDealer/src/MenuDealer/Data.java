package MenuDealer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Data {
    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                String url = "jdbc:mysql://localhost:3306/nama_database"; // Ganti dengan URL database Anda
                String username = "root"; // Ganti dengan nama pengguna database Anda
                String password = ""; // Ganti dengan kata sandi database Anda

                connection = DriverManager.getConnection(url, username, password);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}