import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Pembeli {
    private int Id_pembeli;
    private String nama_pembeli;
    private String Alamat_pembeli;
    private String No_HP;

    public Pembeli(int Id_pembeli, String nama_pembeli, String Alamat_pembeli, String No_HP) {
        this.Id_pembeli = Id_pembeli;
        this.nama_pembeli = nama_pembeli;
        this.Alamat_pembeli = Alamat_pembeli;
        this.No_HP= No_HP;
    }

    // Getter and Setter methods for the fields (id, nama, alamat, telepon)

    public static Pembeli getPembeli(int pembeliId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Menghubungkan ke database
            String url = "jdbc:mysql://localhost:3306/dealer_mobil";
            String user = "root";
            String password = "";
            connection = DriverManager.getConnection(url, user, password);

            // Query untuk mendapatkan pembeli berdasarkan ID
            String query = "SELECT * FROM pembeli WHERE Id_pembeli = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, pembeliId);

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int Id_pembeli = resultSet.getInt("id");
                String nama_pembeli = resultSet.getString("nama_pembeli");
                String Alamat_pembeli = resultSet.getString("Alamat_pembeli");
                String No_HP = resultSet.getString("No_HP");

                return new Pembeli(Id_pembeli, nama_pembeli, Alamat_pembeli, No_HP);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Tutup koneksi database
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return null;
    }
}
