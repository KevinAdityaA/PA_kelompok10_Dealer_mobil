/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package MenuDealer;

import java.util.List;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author ASUS
 */
public class PembeliNGTest {
    
    public PembeliNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getId method, of class Pembeli.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        Pembeli instance = null;
        int expResult = 0;
        int result = instance.getId();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNama method, of class Pembeli.
     */
    @Test
    public void testGetNama() {
        System.out.println("getNama");
        Pembeli instance = null;
        String expResult = "";
        String result = instance.getNama();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getEmail method, of class Pembeli.
     */
    @Test
    public void testGetEmail() {
        System.out.println("getEmail");
        Pembeli instance = null;
        String expResult = "";
        String result = instance.getEmail();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAllPembeli method, of class Pembeli.
     */
    @Test
    public void testGetAllPembeli() {
        System.out.println("getAllPembeli");
        List expResult = null;
        List result = Pembeli.getAllPembeli();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tambahPembeli method, of class Pembeli.
     */
    @Test
    public void testTambahPembeli() {
        System.out.println("tambahPembeli");
        String nama = "";
        String email = "";
        Pembeli.tambahPembeli(nama, email);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
