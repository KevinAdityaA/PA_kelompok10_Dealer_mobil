/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package MenuDealer;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ASUS
 */
public class TransaksiTest {
    
    public TransaksiTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

   
    public void testGetNo_transaksi() {
        System.out.println("getNo_transaksi");
        Transaksi instance = null;
        String expResult = "";
        String result = instance.getNo_transaksi();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTgl_transaksi method, of class Transaksi.
     */
    @Test
    public void testGetTgl_transaksi() {
        System.out.println("getTgl_transaksi");
        Transaksi instance = null;
        String expResult = "";
        String result = instance.getTgl_transaksi();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTgl_transaksi method, of class Transaksi.
     */
    @Test
    public void testSetTgl_transaksi() {
        System.out.println("setTgl_transaksi");
        String Tgl_transaksi = "";
        Transaksi instance = null;
        instance.setTgl_transaksi(Tgl_transaksi);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMetode_pembayaran method, of class Transaksi.
     */
    @Test
    public void testGetMetode_pembayaran() {
        System.out.println("getMetode_pembayaran");
        Transaksi instance = null;
        String expResult = "";
        String result = instance.getMetode_pembayaran();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setMetode_pembayaran method, of class Transaksi.
     */
    @Test
    public void testSetMetode_pembayaran() {
        System.out.println("setMetode_pembayaran");
        String alamat = "";
        Transaksi instance = null;
        instance.setMetode_pembayaran(alamat);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStatus_pembayaran method, of class Transaksi.
     */
    @Test
    public void testGetStatus_pembayaran() {
        System.out.println("getStatus_pembayaran");
        Transaksi instance = null;
        String expResult = "";
        String result = instance.getStatus_pembayaran();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStatus_pembayaran method, of class Transaksi.
     */
    @Test
    public void testSetStatus_pembayaran() {
        System.out.println("setStatus_pembayaran");
        String nomorTelepon = "";
        Transaksi instance = null;
        instance.setStatus_pembayaran(nomorTelepon);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotal_pembayaran method, of class Transaksi.
     */
    @Test
    public void testGetTotal_pembayaran() {
        System.out.println("getTotal_pembayaran");
        Transaksi instance = null;
        String expResult = "";
        String result = instance.getTotal_pembayaran();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTotal_pembayaran method, of class Transaksi.
     */
    @Test
    public void testSetTotal_pembayaran() {
        System.out.println("setTotal_pembayaran");
        String pin = "";
        Transaksi instance = null;
        instance.setTotal_pembayaran(pin);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of login method, of class Transaksi.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        String enteredNo_transaksi = "";
        String enteredTgl_transaksi = "";
        Transaksi instance = null;
        boolean expResult = false;
        boolean result = instance.login(enteredNo_transaksi, enteredTgl_transaksi);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateTotalPembayaran method, of class Transaksi.
     */
    @Test
    public void testUpdateTotalPembayaran() {
        System.out.println("updateTotalPembayaran");
        String newTotalPembayaran = "";
        Transaksi instance = null;
        boolean expResult = false;
        boolean result = instance.updateTotalPembayaran(newTotalPembayaran);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
